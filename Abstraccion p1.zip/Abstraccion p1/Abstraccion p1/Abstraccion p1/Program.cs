﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Abstraccion_p1
{
    class Program
    {
        static void Main(string[] args)
        {//instaciamos y mandamos a llamar al metodo menu
            Menu M = new Menu();
            M.menu();
        }
    }
}
